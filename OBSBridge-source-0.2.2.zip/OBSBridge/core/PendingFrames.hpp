#pragma once
#include <cstddef>
namespace obs {
// Keep the oldest pending frame: dropping the head of a short queue can evict
// every frame before its 180-ms presentation deadline at high input rates.
constexpr size_t MaximumPendingFrames = 12;
template<class Queue, class Value>
bool enqueuePending(Queue &queue, Value value) {
    if (queue.size() >= MaximumPendingFrames) return false;
    queue.push_back(value);
    return true;
}
}
