#import "Receiver.h"
#import "MediaBus.h"
#import "Shared.h"
#include <notify.h>
#include <cmath>
#include <mutex>

namespace {
dispatch_source_t tickTimer;
dispatch_queue_t producerQueue;
std::mutex diagnosticLock;
NSString *lastRequest;
NSString *commandError = @"";
NSString *statusWriteError = @"";
void control(void) {
    NSDictionary *config = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
    NSString *request = config[@"RequestID"];
    NSDate *date = config[@"RequestDate"];
    if (![request isKindOfClass:NSString.class] || [request isEqual:lastRequest] ||
        ![date isKindOfClass:NSDate.class] || fabs(date.timeIntervalSinceNow) > 15) return;
    lastRequest = request;
    BOOL enabled = [config[@"Enabled"] boolValue];
    NSString *bind = config[@"BindIP"], *peer = config[@"PCIP"];
    if (enabled && (![bind isKindOfClass:NSString.class] || ![peer isKindOfClass:NSString.class])) {
        std::lock_guard<std::mutex> lock(diagnosticLock);
        commandError = @"启动配置中的 BindIP/PCIP 类型不正确"; return;
    }
    { std::lock_guard<std::mutex> lock(diagnosticLock); commandError = @""; }
    if (enabled) OBStart(bind, peer); else OBStop();
}
void saveStatus(void) {
    NSDictionary *status = @{@"Version": OB_VERSION, @"Date": [NSDate date],
        @"Text": OBControlStatus(), @"Enabled": @(OBEnabled())};
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:status
        format:NSPropertyListBinaryFormat_v1_0 options:0 error:&error];
    BOOL ok = data && [data writeToFile:OB_STATUS options:NSDataWritingAtomic error:&error];
    NSString *result = ok ? @"" : [NSString stringWithFormat:@"接收层状态文件写入失败：%@ (%@/%ld)",
        error.localizedDescription ?: @"未知错误", error.domain ?: @"", (long)error.code];
    std::lock_guard<std::mutex> lock(diagnosticLock);
    if (![result isEqual:statusWriteError]) {
        statusWriteError = result;
        if (!ok) NSLog(@"[OBSBridge] %@", result);
    }
}
}
NSString *OBControlStatus(void) {
    NSString *command, *file;
    { std::lock_guard<std::mutex> lock(diagnosticLock); command = commandError; file = statusWriteError; }
    return [NSString stringWithFormat:@"%@\n%@\n%@", OBStatus(), command, file];
}
__attribute__((constructor)) static void OBProducerInitialize(void) {
    producerQueue = dispatch_queue_create("local.xiaoguai.obsbridge.producer", DISPATCH_QUEUE_SERIAL);
    dispatch_async(producerQueue, ^{
        @autoreleasepool {
            NSString *error = OBBusCreate();
            if (error) NSLog(@"[OBSBridge] %@", error);
            // Never auto-start an old saved command after SpringBoard restarts.
            NSDictionary *old = [NSDictionary dictionaryWithContentsOfFile:OB_CONFIG];
            NSString *request = old[@"RequestID"];
            if ([request isKindOfClass:NSString.class]) lastRequest = request;
            int token;
            uint32_t rc = notify_register_dispatch(OB_NOTIFY, &token, producerQueue, ^(int value) {
                (void)value; control();
            });
            if (rc != NOTIFY_STATUS_OK) {
                std::lock_guard<std::mutex> lock(diagnosticLock);
                commandError = [NSString stringWithFormat:@"命令通知注册失败：%u；使用控制文件轮询", rc];
            }
            tickTimer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, producerQueue);
            dispatch_source_set_timer(tickTimer, dispatch_time(DISPATCH_TIME_NOW, 0),
                                      NSEC_PER_SEC / 60, NSEC_PER_SEC / 240);
            dispatch_source_set_event_handler(tickTimer, ^{
                @autoreleasepool {
                    OBProducerTick();
                    static unsigned ticks = 0;
                    if (++ticks % 15 == 0) { control(); saveStatus(); }
                }
            });
            dispatch_resume(tickTimer);
            NSLog(@"[OBSBridge] %@ SpringBoard receiver initialized", OB_VERSION);
        }
    });
}
