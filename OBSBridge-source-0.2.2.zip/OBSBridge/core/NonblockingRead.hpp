#pragma once
#include <cmath>

namespace obs {
struct ReadAttempt {
    int bytes;
    int error;
    bool interrupted;
    bool wouldBlock;
};
enum class ReadEnd { Data, Eof, Error, Timeout, Cancelled };
struct ReadResult { ReadEnd end; int bytes; int error; };
// No readiness syscall (poll/select/kqueue). A caller supplies a nonblocking
// receive operation and bounded sleeps. Permission errors remain errors.
template<class Active, class Read, class Clock, class Wait>
ReadResult nonblockingRead(Active active, Read read, Clock clock, Wait wait,
                           double lastData, double maximumIdle = 8) {
    while (active()) {
        ReadAttempt attempt = read();
        if (attempt.bytes > 0) return {ReadEnd::Data, attempt.bytes, 0};
        if (!attempt.bytes) return {ReadEnd::Eof, 0, 0};
        if (attempt.interrupted) continue;
        if (!attempt.wouldBlock) return {ReadEnd::Error, 0, attempt.error};
        double now = clock();
        if (!std::isfinite(now) || !std::isfinite(lastData) || now < lastData || now - lastData > maximumIdle)
            return {ReadEnd::Timeout, 0, 0};
        wait();
    }
    return {ReadEnd::Cancelled, 0, 0};
}
}
