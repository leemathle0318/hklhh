#pragma once
#include "SharedMedia.hpp"
namespace obs {
constexpr uint32_t FileMagic = 0x4f424633, FileVersion = 3;
constexpr size_t MaximumPixels = 1280 * 720, MaximumFrameBytes = MaximumPixels * 4;
// Payload is protected by SharedMedia.video[slot]'s cross-process reader/writer
// lease. Never read/write pixels or dimensions without the corresponding lease.
struct RawVideo {
    uint32_t width = 0, height = 0, stride = 0;
    std::array<uint8_t, MaximumFrameBytes> pixels;
    bool valid() const {
        return width && height && width <= 1280 && height <= 1280 && stride == width * 4 &&
            uint64_t(width) * height <= MaximumPixels;
    }
    bool write(const uint8_t *source, size_t row, uint32_t w, uint32_t h) {
        if (!source || !w || !h || w > 1280 || h > 1280 || uint64_t(w) * h > MaximumPixels || row < size_t(w)*4)
            return false;
        width = w; height = h; stride = w * 4;
        for (uint32_t y = 0; y < h; ++y) std::memcpy(pixels.data()+size_t(y)*stride, source+size_t(y)*row, stride);
        return true;
    }
    bool copy(uint8_t *destination, size_t row, size_t capacity) const {
        if (!valid() || !destination || row < stride || row > SIZE_MAX / height || capacity < row * height)
            return false;
        for (uint32_t y = 0; y < height; ++y) std::memcpy(destination+size_t(y)*row, pixels.data()+size_t(y)*stride, stride);
        return true;
    }
};
struct alignas(64) MappedMedia {
    std::atomic<uint32_t> magic{0};
    uint32_t version = FileVersion;
    uint64_t bytes = sizeof(MappedMedia), cookie = 0;
    SharedMedia state;
    std::array<RawVideo, 3> frames;
    void initialize(uint64_t session) {
        cookie = session; state.initialize(); magic.store(FileMagic, std::memory_order_release);
    }
    bool valid(uint64_t session) const {
        return magic.load(std::memory_order_acquire) == FileMagic && version == FileVersion &&
            bytes == sizeof(MappedMedia) && cookie == session && session != 0;
    }
};
}
