#include "../core/MappedMedia.hpp"
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <memory>
#include <string>
#include <vector>
#include <new>
#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#else
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#endif
using obs::MappedMedia;
static bool inspect(MappedMedia *bus) {
    if (!bus || !bus->valid(77)) return false;
    auto &slot = bus->state.video[0];
    if (!obs::acquireReader(slot)) return false;
    // Leave a lease held for the parent to verify real cross-process atomics.
    std::vector<uint8_t> pixels(24);
    float audio[2]{};
    return bus->frames[0].copy(pixels.data(), 12, pixels.size()) &&
        pixels[0] == 17 && pixels[8] == 0 && pixels[12] == 33 &&
        bus->state.readAudio(audio, 2, 10, 48000, 10000000) && audio[0] == .5f && audio[1] == -.5f;
}
static void prepare(MappedMedia *bus) {
    bus->initialize(77); bus->state.enabled = 1; bus->state.generation = 1; bus->state.heartbeatUS = 10000000;
    const uint8_t pixels[] = {17,18,19,20,21,22,23,24, 0,0,0,0, 33,34,35,36,37,38,39,40, 0,0,0,0};
    auto &slot = bus->state.video[0]; assert(obs::acquireWriter(slot));
    assert(bus->frames[0].write(pixels, 12, 2, 2)); slot.sequence = 1; slot.generation = 1; slot.dueUS = 10000000;
    obs::releaseWriter(slot);
    float audio[] = {.5f,-.5f}; bus->state.writeAudio(audio, 2, 10);
}
#ifdef _WIN32
int wmain(int argc, wchar_t **argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    if (argc == 3 && std::wstring(argv[1]) == L"--file-child") {
        HANDLE file = CreateFileW(argv[2], GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) return 10;
        HANDLE map = CreateFileMappingW(file, nullptr, PAGE_READWRITE, 0, sizeof(MappedMedia), nullptr);
        auto *bus = map ? static_cast<MappedMedia *>(MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(MappedMedia))) : nullptr;
        bool ok = inspect(bus);
        if (bus) UnmapViewOfFile(bus); if (map) CloseHandle(map); CloseHandle(file); return ok ? 0 : 11;
    }
#else
int main() {
#endif
    auto unit = std::make_unique<MappedMedia>(); prepare(unit.get());
    assert(!unit->valid(0) && !unit->valid(78));
    auto &raw = unit->frames[0]; uint8_t tooSmall[7]{};
    assert(!raw.copy(tooSmall, 8, sizeof(tooSmall)));
    assert(!raw.write(tooSmall, 8, 1281, 1));
    uint32_t saved = raw.stride; raw.stride = 0; assert(!raw.valid()); raw.stride = saved;
#ifdef _WIN32
    wchar_t folder[MAX_PATH], path[MAX_PATH]; assert(GetTempPathW(MAX_PATH, folder));
    assert(GetTempFileNameW(folder, L"obm", 0, path));
    HANDLE file = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_TEMPORARY, nullptr); assert(file != INVALID_HANDLE_VALUE);
    HANDLE map = CreateFileMappingW(file, nullptr, PAGE_READWRITE, 0, sizeof(MappedMedia), nullptr); assert(map);
    auto *shared = static_cast<MappedMedia *>(MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(MappedMedia))); assert(shared);
    prepare(new (shared) MappedMedia);
    wchar_t exe[32768]; assert(GetModuleFileNameW(nullptr, exe, 32768));
    std::wstring command = L"\"" + std::wstring(exe) + L"\" --file-child \"" + std::wstring(path) + L"\"";
    STARTUPINFOW startup{}; startup.cb = sizeof(startup); PROCESS_INFORMATION process{};
    assert(CreateProcessW(nullptr, command.data(), nullptr, nullptr, FALSE, CREATE_NO_WINDOW, nullptr, nullptr, &startup, &process));
    assert(WaitForSingleObject(process.hProcess, 10000) == WAIT_OBJECT_0);
    DWORD result = 99; assert(GetExitCodeProcess(process.hProcess, &result)); assert(result == 0);
    CloseHandle(process.hThread); CloseHandle(process.hProcess);
#else
    char path[] = "/tmp/obsbridge-file-XXXXXX";
    int fd = mkstemp(path); assert(fd >= 0); assert(ftruncate(fd, sizeof(MappedMedia)) == 0);
    void *memory = mmap(nullptr, sizeof(MappedMedia), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0); assert(memory != MAP_FAILED);
    auto *shared = new (memory) MappedMedia; prepare(shared);
    pid_t pid = fork(); assert(pid >= 0);
    if (!pid) {
        munmap(memory, sizeof(MappedMedia)); close(fd);
        int other = open(path, O_RDWR | O_NOFOLLOW); if (other < 0) _exit(10);
        void *view = mmap(nullptr, sizeof(MappedMedia), PROT_READ | PROT_WRITE, MAP_SHARED, other, 0); close(other);
        if (view == MAP_FAILED) _exit(11);
        bool ok = inspect(static_cast<MappedMedia *>(view)); munmap(view, sizeof(MappedMedia)); _exit(ok ? 0 : 12);
    }
    int result = 99; assert(waitpid(pid, &result, 0) == pid); assert(WIFEXITED(result) && WEXITSTATUS(result) == 0);
#endif
    assert(shared->state.video[0].lease.load() == 1);
    assert(!obs::acquireWriter(shared->state.video[0])); obs::releaseReader(shared->state.video[0]);
    assert(obs::acquireWriter(shared->state.video[0])); obs::releaseWriter(shared->state.video[0]);
#ifdef _WIN32
    UnmapViewOfFile(shared); CloseHandle(map); CloseHandle(file); assert(DeleteFileW(path));
#else
    munmap(memory, sizeof(MappedMedia)); close(fd); assert(unlink(path) == 0);
#endif
    std::printf("PASS: raw BGRA bounds/stride/session; two real processes open the same file and share pixels, PCM, leases; %zu bytes\n", sizeof(MappedMedia));
}
